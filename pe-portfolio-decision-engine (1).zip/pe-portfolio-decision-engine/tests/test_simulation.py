import numpy as np
import pytest
from model import default_config
from simulation import validate_probabilities, run_simulation

def test_paired_no_action_zero_per_draw():
    c=default_config()
    sm,raw,_=run_simulation(c)
    assert np.all(raw["No new deployment"]["incremental"]==0)

def test_probability_validation():
    assert validate_probabilities([.2,.6,.2]).sum()==pytest.approx(1)
    with pytest.raises(ValueError):
        validate_probabilities([.3,.6,.2])
    with pytest.raises(ValueError):
        validate_probabilities([-.2,1.2])

def test_identical_seed_reproduces_every_draw():
    c=default_config()
    _,a,_=run_simulation(c)
    _,b,_=run_simulation(c)
    for key in a:
        assert np.array_equal(a[key]["cash"],b[key]["cash"])
        assert np.array_equal(a[key]["incremental"],b[key]["incremental"])

def test_failure_holds_full_capital_at_risk():
    c=default_config()
    for market in c["simulation"]["execution_probs"]:
        c["simulation"]["execution_probs"][market]=dict(Success=0,Partial=0,Failure=1,Delay=0)
    _,out,_=run_simulation(c)
    assert np.allclose(out["IT Full"]["incremental"],-8)
    assert np.allclose(out["Security Pilot only"]["incremental"],-4)
    assert np.allclose(out["IT Full + Security Pilot"]["incremental"],-12)

def test_all_closing_after_m24_is_not_cash():
    c=default_config()
    c["exit_months"]={name:25 for name in c["exit_months"]}
    _,out,_=run_simulation(c)
    assert np.all(out["No new deployment"]["cash"]==15)
    assert np.all(out["IT Full"]["cash"]==7)
    assert np.all(out["IT Full"]["incremental"]==-8)

def test_market_execution_dependence():
    c=default_config()
    c["simulation"]["market_probs"]=dict(Adverse=1,Base=0,Favorable=0)
    c["simulation"]["execution_probs"]["Adverse"]=dict(Success=1,Partial=0,Failure=0,Delay=0)
    c["simulation"]["n"]=1000
    _,o,_=run_simulation(c)
    assert np.allclose(o["IT Full"]["incremental"],3.76)
    assert np.allclose(o["IT Full + Security Pilot"]["incremental"],2.82)

def test_c8_exact_discrete_analytic_expectation_convergence():
    c=default_config()
    c["simulation"]["n"]=100000
    _,o,_=run_simulation(c)
    expected={"No new deployment":(136.788,0),
      "IT Full":(143.494,6.706),"Security Pilot only":(138.247,1.459),
      "IT Full + Security Pilot":(144.953,8.165),
      "Security Full":(131.903,-4.885),
      "E-commerce Full":(136.708,-.080),
      "IT Full + Security Pilot + E-commerce Partial":(145.758,8.970)}
    for name,(target_cash,target_delta) in expected.items():
        assert o[name]["cash"].mean()==pytest.approx(target_cash,abs=0.5)
        assert o[name]["incremental"].mean()==pytest.approx(target_delta,abs=0.15)

def test_staged_milestone_retains_cash_when_unreleased():
    c=default_config()
    c["milestone_probability"]=0.0
    c["simulation"]["n"]=1000
    _,o,_=run_simulation(c)
    assert np.all(o["IT Full (Staged)"]["deployed"]==4)
    assert np.all(o["IT Full (Staged)"]["incremental"]==-4)

def test_zero_shared_factor_is_psd_and_runs():
    c=default_config()
    c["simulation"].update(common_factor=0,ebitda_vol=.2,multiple_vol=.1,debt_vol=3)
    _,a,_=run_simulation(c)
    assert np.isfinite(a["No new deployment"]["cash"]).all()

def test_cofund_cash_consumption():
    c=default_config()
    c["financing_mode"]="Confirmed co-funding"
    c["cofund_confirmed"]=True
    c["fund_contributions"]["IT Full"]=3
    _,out,_=run_simulation(c)
    assert np.all(out["IT Full"]["deployed"]==3)
