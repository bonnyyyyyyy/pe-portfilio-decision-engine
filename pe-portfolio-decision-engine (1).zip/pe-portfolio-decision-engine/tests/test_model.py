import copy
import pytest
from model import default_config, compare, evaluate, exit_equity, company_forecast
from strategies import validate_strategy

FIXTURES={
 "No new deployment":(134.8,0),
 "IT Full":(147.8,13),
 "IT Full + Security Pilot":(152.4,17.6),
 "Security Pilot only":(139.4,4.6),
 "Security Full":(137.0,2.2),
 "E-commerce Full":(141.75,6.95),
 "E-commerce Partial":(137.5,2.7),
 "IT Full + E-commerce Partial":(150.5,15.7),
 "Security Pilot + E-commerce Full":(146.35,11.55),
 "Security Pilot + E-commerce Partial":(142.1,7.3),
}
@pytest.mark.parametrize("name,expected",FIXTURES.items())
def test_c9_reconciliation(name,expected):
    actual=compare(name,default_config())
    assert actual["terminal_cash"]==pytest.approx(expected[0],abs=1e-9)
    assert actual["incremental"]==pytest.approx(expected[1],abs=1e-9)
    assert actual["terminal_cash"]==pytest.approx(actual["realized"]+actual["retained"])

def test_it_and_pilot_cash_breakdown():
    row=compare("IT Full + Security Pilot",default_config())
    assert row["companies"]["IT Engineering"]["cash"]==pytest.approx(39.6)
    assert row["companies"]["Security Hardware"]["cash"]==pytest.approx(109.8)
    assert row["realized"]==pytest.approx(149.4)
    assert row["retained"]==pytest.approx(3)
    assert row["terminal_cash"]==pytest.approx(152.4)

def test_funding_is_only_subtracted_once():
    cfg=default_config()
    before=compare("Security Pilot only",cfg)
    cfg["programmes"]["Security Pilot"]["total_cost"]=5
    after=compare("Security Pilot only",cfg)
    assert after["terminal_cash"]-before["terminal_cash"]==pytest.approx(-1)
    assert after["retained"]==pytest.approx(before["retained"]-1)
    assert after["realized"]==pytest.approx(before["realized"])

def test_zero_intervention_benefit_wastes_full_cost():
    cfg=default_config()
    for pname,p in cfg["programmes"].items():
        c=p["company"]
        p["funded_ebitda"]=cfg["no_action"][c]["ebitda"]
        p["funded_multiple"]=cfg["no_action"][c]["multiple"]
    for name,cost in [("IT Full",8),("Security Pilot only",4),("IT Full + Security Pilot",12)]:
        assert compare(name,cfg)["incremental"]==pytest.approx(-cost)

def test_m24_exit_closure_excludes_unrealized():
    cfg=default_config()
    cfg["exit_months"]["Security Hardware"]=25
    x=evaluate("No new deployment",cfg)
    assert x["companies"]["Security Hardware"]["cash"]==0
    assert x["companies"]["Security Hardware"]["unrealized"]==pytest.approx(101.2)
    assert x["terminal_cash"]==pytest.approx(33.6)

def test_future_escrow_not_cash():
    cfg=default_config()
    cfg["escrow"]=0.10
    x=evaluate("No new deployment",cfg)
    assert x["terminal_cash"]==pytest.approx(15+119.8*0.9)
    assert x["withheld"]==pytest.approx(11.98)

def test_strategy_constraints():
    cfg=default_config()
    cfg["budget"]=10
    with pytest.raises(ValueError,match="Insufficient"):
        validate_strategy("IT Full + Security Pilot",cfg)
    cfg=default_config()
    # A user's entered second intensive programme triggers the management rule.
    cfg["programmes"]["Security Pilot"]["intensive"]=True
    with pytest.raises(ValueError,match="Only one"):
        validate_strategy("IT Full + Security Pilot",cfg)

def test_multiple_increases_equity_proceeds():
    cfg=default_config()
    old=evaluate("No new deployment",cfg)["companies"]["Security Hardware"]["cash"]
    cfg["no_action"]["Security Hardware"]["multiple"]=7
    new=evaluate("No new deployment",cfg)["companies"]["Security Hardware"]["cash"]
    assert new>old and new-old==pytest.approx(17.2)

def test_no_negative_ebitda_multiple_valuation():
    assert exit_equity(-2,5,35)==0
    assert exit_equity(-2,5,35,7)==7

def test_revenue_margin_driver_explicit():
    cfg=default_config()
    cfg["no_action"]["IT Engineering"]["exit_revenue"]=300
    assert evaluate("No new deployment",cfg)["companies"]["IT Engineering"]["ebitda"]==15.5
    cfg["forecast_modes"]["IT Engineering"]="Revenue × Margin"
    cfg["forecast_margins"]["IT Engineering"]=0.12
    assert evaluate("No new deployment",cfg)["companies"]["IT Engineering"]["ebitda"]==pytest.approx(36)

def test_pro_rata_participation_cannot_be_assumed():
    cfg=default_config()
    cfg["financing_mode"]="Pro-rata co-funding"
    with pytest.raises(ValueError,match="not confirmed"):
        validate_strategy("IT Full",cfg)
    cfg["cofund_confirmed"]=True
    assert validate_strategy("IT Full",cfg)["deployed"]==pytest.approx(2.4)

def test_budget_unchanged_after_return():
    cfg=default_config()
    assert cfg["budget"]==pytest.approx(15)
    compare("IT Full",cfg)
    assert cfg["budget"]==pytest.approx(15)
